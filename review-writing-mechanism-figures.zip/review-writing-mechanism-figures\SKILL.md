---
name: review-writing-mechanism-figures
description: Medical/biomedical review-writing and mechanism-figure project workflow. Use when the user wants to write a review article, especially oncology, immunology, metabolism, single-cell/spatial omics, or mechanism-focused biomedical reviews, with topic selection, literature search, user-confirmed reference count, outline confirmation, manuscript drafting, imagegen-based mechanism figures, two-round review and revision, target-journal formatting, EndNote-ready Word output, cover letter, and organized submission folders. Also trigger on Chinese requests such as 综述书写、医学综述、肿瘤综述、机制图绘制、投稿版Word、EndNote参考文献、双轮盲审修改、cover letter、期刊推荐.
---

# Review Writing And Mechanism Figures

Use this skill as a light orchestrator for biomedical review projects. Do not duplicate the full logic of upstream skills. Dispatch the right specialist skill at each stage and keep the project files organized.

## Core Principle

Create a complete submission package, not just a manuscript. The package must include the final manuscript, final figures, EndNote-ready reference workflow, cover letter, revision history, journal-format plan, and process records.

## Project Initialization

At the beginning of every project, create a project folder in the current workspace named:

```text
YYYYMMDD_HHMM_review
```

Use the local date and time. Example:

```text
20260626_2130_review/
```

Create this folder structure:

```text
YYYYMMDD_HHMM_review/
  final_submission/
    figures/
    tables/
  revision/
    original/
    round1_nature_review/
    round2_academic_review/
    figures_working/
    literature/
  journal_selection/
  process_record/
```

Store final manuscript and final figures only under `final_submission/`. Store original drafts, revision drafts, review reports, response documents, working figures, and literature screening logs under `revision/`. Store journal recommendation and target journal requirements under `journal_selection/`. Store workflow logs, version maps, and integrity reports under `process_record/`.

## Mandatory User Choices

Before any stage that has modes, explain each mode's advantages and disadvantages, give one recommendation with reasons, then let the user choose. Do not silently select a mode.

The user must confirm:

- review topic/direction
- reference count
- paper outline
- figure scientific content
- writing mode when alternatives exist
- figure generation mode
- review mode when alternatives exist
- target journal before final formatting

## Workflow

### 1. Topic Selection

Dispatch `deep-research`.

Produce 3-5 possible review directions. Compare novelty, overlap/repetition risk, recent research density, feasibility, and target-journal viability. Recommend one direction, but require user confirmation.

### 2. Literature Search And Reference Pool

Dispatch `nature-academic-search`.

Use multi-source literature search, MeSH/PubMed strategy when appropriate, DOI/PMID/title verification, deduplication, screening, and evidence stratification. Generate a literature matrix and an EndNote-importable library file such as `.ris`, `.nbib`, or `.bib`.

Hard rule: never prescribe the reference count by default. Ask the user how many references to retain, or recommend a count and ask for confirmation.

Save outputs under:

```text
revision/literature/
```

### 3. Review Outline

Dispatch `academic-paper`.

Offer these modes:

- `plan`: deeper guided reasoning; slower; best when the argument is still evolving.
- `outline-only`: faster; directly produces structures, headings, and word allocation; less deep than plan.

Recommend a mode with reasons, then wait for the user to choose. Produce two outline options. Do not draft the manuscript until the user confirms one outline.

### 4. Initial Draft

Dispatch `academic-paper`.

Offer these modes:

- `full`: complete drafting workflow; good when only the topic is fixed.
- `write-from-approved-outline`: internal workflow label; write strictly from the user-approved outline.

Recommend `write-from-approved-outline` when an outline has already been confirmed. Save the original draft under:

```text
revision/original/
```

### 5. Mechanism Figure Design

Before drawing, define each figure's scientific conclusion. For each of 3-4 figures, specify title, mechanism, required cells/molecules/tissue structures, spatial relationships, reading order, and figure legend points.

The user must confirm figure content before generation. Do not make ordinary box-and-arrow diagrams as final mechanism figures.

### 6. Mechanism Figure Generation

Dispatch `imagegen` for biological base images, then use Python for deterministic labeling and layout checks.

Offer these modes:

- `imagegen-base-only`: fast visual style exploration; not suitable for final text labels.
- `imagegen-plus-python-labeling`: imagegen base image plus Python labels, leader lines, font control, and overlap checks; recommended for submission figures.

Hard rules:

- imagegen generates biological base images.
- Final labels, fonts, leader lines, and collision avoidance are handled by Python.
- Do not rely on imagegen to produce final textual labels.
- Fonts must be uniform.
- Font size must match figure size.
- Labels must not cover key biological elements.
- Export final figures as PNG and PDF unless the target journal requires another format.

Store working images under:

```text
revision/figures_working/
```

Store final journal-ready figures later under:

```text
final_submission/figures/
```

### 7. First-Round Review: High-Standard Review

Dispatch `nature-reviewer`.

Use it as a high-standard pre-submission review focused on novelty, significance, technical soundness, main argument, review depth, and whether figures support the manuscript's claims. Save reports under:

```text
revision/round1_nature_review/
```

### 8. First-Round Response And Revision

Always perform this in two ordered steps:

1. Dispatch `nature-response`.
2. Dispatch `academic-paper` in `revision` mode.

Do not revise directly from raw `nature-reviewer` reports.

`nature-response` must first parse the three reviewer reports and cross-review synthesis, classify all comments by severity and type, and generate:

- comment classification table
- revision strategy
- revision checklist
- revision priority
- manuscript-change map
- point-by-point response draft

Mark missing author decisions as `AUTHOR_INPUT_NEEDED`. Do not invent completed edits.

Then pass the confirmed revision checklist and manuscript-change map to `academic-paper revision` to revise the manuscript, figure legends, figure descriptions, and references. Save all files under:

```text
revision/round1_nature_review/
```

### 9. Second-Round Review: Broad Submission Review

Dispatch `academic-paper-reviewer`.

Offer these modes:

- `full`: most comprehensive; includes EIC, methodology, domain, cross-disciplinary, and Devil's Advocate reviewers.
- `quick`: faster high-level screen; less detailed.
- `methodology-focus`: useful for method-heavy research papers; usually less suitable for narrative biomedical reviews.
- `re-review`: verifies whether a revision addressed prior comments; not suitable as the first broad second-round review.

Recommend `full` for a normal second-round pre-submission review, then let the user choose. Save outputs under:

```text
revision/round2_academic_review/
```

### 10. Second-Round Revision

Dispatch `academic-paper` in `revision` mode.

Revise according to the second-round Revision Roadmap. Produce the second revised manuscript, response document, cumulative revision summary, and unresolved issue list. Save outputs under:

```text
revision/round2_academic_review/
```

### 11. Final Integrity Check

Dispatch `academic-paper citation-check` and apply internal checks.

Check:

- in-text citations versus reference library
- DOI/PMID/year/journal correctness
- figure/table numbering and legends
- unsupported claims
- AI disclosure
- conflict of interest
- funding statement
- data availability statement
- target-journal required declarations

Save the report to:

```text
process_record/integrity_check_report.md
```

### 12. Journal Recommendation

Use `nature-academic-search` and web verification when current journal information matters.

Recommend 3-5 matched journals, considering CAS partition, scope, review article policy, review speed, APC, impact factor, recent similar reviews, and relative acceptance difficulty. The user must choose the target journal before final formatting.

Save outputs under:

```text
journal_selection/
```

### 13. Target Journal Requirements

After the user chooses the journal, retrieve or inspect the current Guide for Authors. Summarize:

- article type
- word limit
- abstract structure
- keywords
- headings
- figure requirements
- table requirements
- reference style
- EndNote style if available
- cover letter requirements
- declaration requirements
- submission checklist

Save:

```text
journal_selection/guide_for_authors_snapshot.md
final_submission/target_journal_format_plan.md
final_submission/submission_checklist.md
```

### 14. Final Manuscript Formatting And EndNote Workflow

Dispatch `academic-paper format-convert` and apply the EndNote workflow.

The final Word manuscript must be EndNote-ready. Do not treat plain-text references as the final submission reference workflow unless the user explicitly accepts that limitation.

Load `references/endnote-word-automation.md` before attempting Word + EndNote automation.

Default behavior:

1. Generate `.ris` or `.nbib` for EndNote import.
2. Generate an EndNote-ready Word file with temporary citations or another user-confirmed EndNote-compatible citation marker scheme.
3. If a matching EndNote library is available, try Word automation and `ENFormatBibliography`.
4. If automation fails, provide exact manual EndNote Cite While You Write steps.

Save:

```text
final_submission/final_manuscript_before_endnote.md
final_submission/final_manuscript_endnote_ready.docx
final_submission/reference_library.ris
```

### 15. Final Figure Formatting

Use Python and target-journal requirements to format final figures.

Check and adjust file format, resolution, width, font size, panel labels, color mode, and legend placement. Save final images under:

```text
final_submission/figures/
```

### 16. Cover Letter

Draft a journal-specific cover letter after the target journal and final manuscript are fixed.

Include manuscript title, target journal, article type, topic, journal fit, key contributions, value to readers, no simultaneous submission statement, conflict-of-interest statement, corresponding author placeholder, and reviewer suggestion/exclusion placeholders if required.

Do not use a generic cover-letter template. Tie the letter to the target journal scope and final manuscript.

Save:

```text
final_submission/cover_letter.md
final_submission/cover_letter.docx
```

### 17. Submission Package Assembly

Ensure final files are organized:

```text
final_submission/
  final_manuscript_endnote_ready.docx
  final_manuscript_before_endnote.md
  cover_letter.docx
  cover_letter.md
  figures/
  tables/
  reference_library.ris
  target_journal_format_plan.md
  submission_checklist.md

revision/
  original/
  round1_nature_review/
  round2_academic_review/
  figures_working/
  literature/

journal_selection/
  journal_recommendations.md
  selected_journal_notes.md
  guide_for_authors_snapshot.md

process_record/
  workflow_log.md
  version_map.md
  integrity_check_report.md
```

## EndNote Automation Boundary

This user's machine has been tested:

- Word COM automation is available.
- Word version detected: 16.0.
- Word has `EndNote.WordAddin.Connect` enabled.
- The `EndNote Cite While You Write` add-in is connected.
- The Word macro `ENFormatBibliography` can be invoked programmatically.
- Direct citation insertion macros such as `ENInsertCitation` were not available in the smoke test.
- The EndNote add-in did not expose a direct COM object.
- Formatting a temporary citation did not succeed without a matching open EndNote library and valid record numbers.

Therefore, promise EndNote-ready output and best-effort formatting automation, not guaranteed fully automatic citation insertion.

## Hard Rules

1. Create a `YYYYMMDD_HHMM_review` project folder before substantive work.
2. Do not prescribe the reference count; ask the user.
3. Explain mode pros/cons before every mode choice; recommend one mode with reasons; let the user decide.
4. Confirm outline before drafting.
5. Confirm figure scientific content before drawing.
6. Use imagegen for biological base images and Python for final labels.
7. First-round review uses `nature-reviewer`.
8. First-round revision must run `nature-response` before `academic-paper revision`.
9. Second-round review uses `academic-paper-reviewer`.
10. Second-round revision uses `academic-paper revision`.
11. Do final formatting only after the user chooses a target journal.
12. Follow the target journal Guide for Authors for manuscript and figure formatting.
13. Use an EndNote-ready Word workflow; do not claim fully automatic EndNote insertion unless verified for the current library.
14. Create a journal-specific cover letter.
15. Preserve original, revised, final, review, response, and revision-summary artifacts.
