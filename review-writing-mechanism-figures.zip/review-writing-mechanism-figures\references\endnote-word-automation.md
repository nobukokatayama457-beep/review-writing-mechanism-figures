# EndNote Word Automation

Load this reference only during final manuscript formatting or when the user asks whether EndNote can be automated.

## Local Capability Test Result

On this user's machine, the following smoke test was performed:

- Word COM automation is available.
- Word version: `16.0`.
- Word path: `C:\Program Files\Microsoft Office\Root\Office16`.
- Word COM add-in detected: `EndNote.WordAddin.Connect`.
- Add-in description: `EndNote Cite While You Write`.
- Add-in connection state: `true`.
- The add-in did not expose a callable COM object through `COMAddIns.Item(...).Object`.
- The macro `ENFormatBibliography` could be invoked through Word automation.
- Common insert-citation macro attempts such as `ENInsertCitation` did not run.
- A test document containing `{Finn, 2020 #1}` was not formatted into a bibliography, likely because no matching EndNote library/record was open or available.

## Practical Boundary

Do not promise fully automatic EndNote citation insertion.

The supported commitment is:

1. Generate an EndNote-importable library file such as `.ris` or `.nbib`.
2. Generate an EndNote-ready Word manuscript.
3. Use temporary citations only when the user has confirmed the expected EndNote temporary citation pattern and record-number availability.
4. Try `ENFormatBibliography` as a best-effort automation step when Word and EndNote are available.
5. If automation fails, provide exact manual EndNote Cite While You Write steps.

## Recommended Final-Formatting Procedure

1. Export the verified reference library as `.ris` or `.nbib`.
2. Ask the user whether they already have an EndNote library for the manuscript.
3. If the user has a library, ask whether temporary citations should use record numbers, author-year placeholders, or another agreed marker scheme.
4. Generate the Word manuscript with EndNote-ready placeholders.
5. Try Word automation:

```powershell
$word = New-Object -ComObject Word.Application
$doc = $word.Documents.Open("<docx-path>")
$word.Run("ENFormatBibliography")
$doc.Save()
$doc.Close()
$word.Quit()
```

6. Inspect whether temporary citations were converted.
7. If conversion fails, leave the document EndNote-ready and provide manual steps.

## Manual CWYW Steps To Provide When Needed

Tell the user:

1. Open the `.ris` or `.nbib` file in EndNote and save it as an EndNote library.
2. Open the EndNote library before opening the Word manuscript.
3. Open the Word manuscript.
4. Use EndNote's `Cite While You Write` tab.
5. Select the required journal output style, or import/download the journal's EndNote style if needed.
6. Use `Update Citations and Bibliography` / `Format Bibliography`.
7. Inspect unresolved temporary citations and replace them manually using `Insert Citation`.
8. Save the formatted submission copy as a new file.

## Failure Cases

Treat these as expected limitations, not as pipeline failures:

- EndNote desktop app is not discoverable even though the Word add-in exists.
- EndNote library is not open.
- Temporary citation record numbers do not match the user's library.
- The target journal EndNote style is not installed.
- Word or EndNote shows a modal dialog requiring user interaction.
- Institution-managed Office blocks macro invocation.

When any of these occur, keep the generated Word document and reference library, then mark the EndNote step as `USER_ACTION_REQUIRED`.
